/**
The contents of this file are subject to the Mozilla Public License Version 1.1
(the "License"); you may not use this file except in compliance with the License.
You may obtain a copy of the License at http://www.mozilla.org/MPL/
Software distributed under the License is distributed on an "AS IS" basis,
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for the
specific language governing rights and limitations under the License.

The Original Code is "DemoView.java".  Description:
"Simple example C.C.S.G.S demo"

The Initial Developer of the Original Code is University Health Network. Copyright (C)
2001.  All Rights Reserved.

Contributor(s): James Agnew.

Alternatively, the contents of this file may be used under the terms of the
GNU General Public License (the  ~SGPL~T), in which case the provisions of the GPL are
applicable instead of those above.  If you wish to allow use of your version of this
file only under the terms of the GPL and not to allow others to use your version
of this file under the MPL, indicate your decision by deleting  the provisions above
and replace  them with the notice and other provisions required by the GPL License.
If you do not delete the provisions above, a recipient may use your version of
this file under either the MPL or the GPL.

*/

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import demo.*;

/** 
 * Simple demo class. This was thrown together, so don't expect much style..
 */
public class DemoView extends javax.swing.JDialog {

	demo.MsgADTA01 confMessage;

	/** 
	 * Creates a new instance of the demo application 
	 */
	public DemoView(java.awt.Frame parent, boolean modal) {
		super(parent, modal);
		confMessage = new MsgADTA01();
		initComponents();
	}

	/** 
	 * Executes the demo application
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		JFrame theFrame = new JFrame();
		DemoView theView = new DemoView(theFrame, false);
		theView.setSize(640, 400);
		theView.setLocation( 100, 100);
		theView.show();
		theView.setTitle("Conformance API Example");
	}

	/**
	 * This method sets up the gui. It was automatically generated using
	 * NetBeans IDE, and modified slightly.
	 */
	private void initComponents() {
		java.awt.GridBagConstraints gridBagConstraints;

		tabPane = new javax.swing.JTabbedPane();
		entryTab = new javax.swing.JPanel();
		jPanel1 = new javax.swing.JPanel();
		jLabel3 = new javax.swing.JLabel();
		dateTimeOfMessage = new javax.swing.JTextField();
		jLabel4 = new javax.swing.JLabel();
		sequenceID = new javax.swing.JTextField();
		namePanel = new javax.swing.JPanel();
		pidPanel = new javax.swing.JPanel();
		repetitionLabel = new javax.swing.JLabel();
		patientNameLabel = new javax.swing.JLabel();
		patientNameBox = new javax.swing.JTextField();
		telephoneSpinner = new javax.swing.JSpinner();
		postalCodeLabel = new javax.swing.JLabel();
		postalCodeBox = new javax.swing.JTextField();
		jLabel9 = new javax.swing.JLabel();
		phoneNumberLabel = new javax.swing.JLabel();
		phoneNumberBox = new javax.swing.JTextField();
		jPanel2 = new javax.swing.JPanel();
		panelPV1 = new javax.swing.JPanel();
		jLabel7 = new javax.swing.JLabel();
		roomLabel = new javax.swing.JLabel();
		roomBox = new javax.swing.JTextField();
		locationSpinner = new javax.swing.JSpinner();
		bedLabel = new javax.swing.JLabel();
		bedBox = new javax.swing.JTextField();
		messageGenTab = new javax.swing.JPanel();
		generateButton = new javax.swing.JButton();
		xmlScroller = new javax.swing.JScrollPane();
		xmlBox = new javax.swing.JTextArea();
		buildingLabel = new javax.swing.JLabel();
		building = new javax.swing.JTextField();

		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent evt) {
				closeDialog(evt);
			}
		});

		entryTab.setLayout(new BoxLayout(entryTab, BoxLayout.Y_AXIS));

		namePanel.setLayout(new java.awt.GridLayout(1, 1, 1, 1));

		namePanel.setBorder(new javax.swing.border.TitledBorder(null, "Patient ID", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 14), new java.awt.Color(51, 51, 255)));
		pidPanel.setLayout(new java.awt.GridLayout(3, 3, 2, 2));

		repetitionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		repetitionLabel.setText("Repetition");
		pidPanel.add(repetitionLabel);

		// Patient Name Box
		patientNameLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
		patientNameLabel.setText("Patient Name");
		pidPanel.add(patientNameLabel);
		patientNameBox.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyPressed(java.awt.event.KeyEvent evt) {
				dataEntryHandler( evt );
			}
		});
		pidPanel.add(patientNameBox);


		telephoneSpinner.setFont( new java.awt.Font("Dialog", 1, 14).deriveFont(Font.BOLD) );
		telephoneSpinner.setValue( new Integer(1) );
		pidPanel.add(telephoneSpinner);

		postalCodeLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
		postalCodeLabel.setText("Postal Code");
		pidPanel.add(postalCodeLabel);

		postalCodeBox.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyPressed(java.awt.event.KeyEvent evt) {
				dataEntryHandler( evt );
			}
		});

		pidPanel.add(postalCodeBox);

		pidPanel.add(jLabel9);

		phoneNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
		phoneNumberLabel.setText("Phone Number");
		pidPanel.add(phoneNumberLabel);

		phoneNumberBox.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyPressed(java.awt.event.KeyEvent evt) {
				dataEntryHandler( evt );
			}
		});

		pidPanel.add(phoneNumberBox);

		namePanel.add(pidPanel);

		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 0;
		gridBagConstraints.gridy = 2;
		gridBagConstraints.gridwidth = 11;
		gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
		entryTab.add(namePanel, gridBagConstraints);

		jPanel2.setLayout(new java.awt.GridLayout(1, 0));

		jPanel2.setBorder(new javax.swing.border.TitledBorder(null, "Patient Visit 1 (PV1)", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 14), new java.awt.Color(51, 51, 255)));
		panelPV1.setLayout(new java.awt.GridLayout(3, 3, 2, 2));

		panelPV1.setBorder(new javax.swing.border.TitledBorder("Assigned Patient Location"));
		panelPV1.add(new javax.swing.JLabel(""));

		roomLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
		roomLabel.setText("Room");
		panelPV1.add(roomLabel);
		roomBox.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyPressed(java.awt.event.KeyEvent evt) {
				dataEntryHandler( evt );
			}
		});
		panelPV1.add(roomBox);

		panelPV1.add(new javax.swing.JLabel(""));

		bedLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
		bedLabel.setText("Bed");
		panelPV1.add(bedLabel);

		bedBox.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyPressed(java.awt.event.KeyEvent evt) {
				dataEntryHandler(evt);
			}
		});
		panelPV1.add(bedBox);

		buildingLabel.setText("Building");
		buildingLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
		panelPV1.add(new javax.swing.JLabel(""));
		panelPV1.add(buildingLabel);

		try {
			building.setText( confMessage.getPV1().getAssignedPatientLocation().getBuilding().getConstantValue() );
		} catch ( ca.uhn.hl7v2.conf.classes.exceptions.ConfRepException e ) {
			// Technically, this shouldn't happen. as this exception is only
			// thrown on a bad repetition attempt, and the above statement does
			// not access any multi-repetition message elements. 
			JOptionPane.showMessageDialog(null, "Error!", "Error!\n" + e.toString(), JOptionPane.ERROR_MESSAGE);
		}
		
		building.setEnabled(false);
		panelPV1.add(building);

		jPanel2.add(panelPV1);

		gridBagConstraints = new java.awt.GridBagConstraints();
		gridBagConstraints.gridx = 0;
		gridBagConstraints.gridy = 4;
		gridBagConstraints.gridwidth = 11;
		gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
		entryTab.add(jPanel2, gridBagConstraints);

		tabPane.addTab("Data Entry", entryTab);

		messageGenTab.setLayout(new javax.swing.BoxLayout(messageGenTab, javax.swing.BoxLayout.X_AXIS));

		generateButton.setText("Generate Message");
		generateButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				generateButtonActionPerformed(evt);
			}
		});

		messageGenTab.add(generateButton);

		xmlBox.setFont(new java.awt.Font("Dialog", 0, 18));
		xmlScroller.setViewportView(xmlBox);

		messageGenTab.add(xmlScroller);

		tabPane.addTab("Message Generation", messageGenTab);

		getContentPane().setLayout( new BoxLayout(getContentPane(), BoxLayout.Y_AXIS) );
		
		JLabel topLabel = new JLabel();
		topLabel.setAlignmentX(JLabel.LEFT);
		topLabel.setForeground( Color.RED );
		topLabel.setFont( new java.awt.Font("Dialog", 1, 14) );
		topLabel.setText("Example Tool built against a Conformance API");
		
		getContentPane().add(topLabel);
		getContentPane().add(tabPane);

		pack();
	}

	/**
	 * Performs the actual message encoding (generates an XML HL7 message)
	 * @param evt
	 */
	private void generateButtonActionPerformed(java.awt.event.ActionEvent evt) { 
		// Create an instance of the HAPI message encoder
		ca.uhn.hl7v2.parser.DefaultXMLParser parser = new ca.uhn.hl7v2.parser.DefaultXMLParser();
		
		// A conformance class set contains an underlying message object. Retrieve it.
		ca.uhn.hl7v2.model.Message underlyingMessage = confMessage.getHAPIMessage();

		// Encode the message and stuff it into the text box
		try {
			String encodedMessage = parser.encode( underlyingMessage );
			xmlBox.setText( encodedMessage );
		} catch ( ca.uhn.hl7v2.HL7Exception e ) {
			JOptionPane.showMessageDialog(null, "Error!", "Error!", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}

	} 

	/**
	 * Called when ENTER is pressed in a text box, to stick that value into the
	 * conformance classes.
	 * @param evt
	 */
	private void dataEntryHandler( java.awt.event.KeyEvent evt ) {
		
		// only handle the enter key
		if ( evt.getKeyCode() != KeyEvent.VK_ENTER )
			return;

		String value = ((JTextField) evt.getSource()).getText();

		// Find out which primitive is being modified
		try {
			if (evt.getSource() == patientNameBox)
				confMessage.getPID().getPatientName( 1 ).getGivenName().setValue( value );
			else if (evt.getSource() == postalCodeBox)
				confMessage.getPID().getPatientAddress( Integer.parseInt(telephoneSpinner.getValue().toString()) ).getZipOrPostalCode().setValue( value );
			else if (evt.getSource() == phoneNumberBox) 
				confMessage.getPID().getPhoneNumberHome( 1 ).getPhoneNumber().setValue( value );
			else if (evt.getSource() == roomBox)
				confMessage.getPV1().getAssignedPatientLocation().getRoom().setValue( value );
			else if (evt.getSource() == bedBox)
				confMessage.getPV1().getAssignedPatientLocation().getBed().setValue( value );

			JOptionPane.showMessageDialog(null, "Success!", "Success!", JOptionPane.INFORMATION_MESSAGE);

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Error!" + e.toString(), "Error! " + e.toString(), JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}

	}

	/** Closes the dialog */
	private void closeDialog(java.awt.event.WindowEvent evt) {
		setVisible(false);
		dispose();
		System.exit(0);
	}

	// Variables declaration
	private javax.swing.JLabel repetitionLabel;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JPanel entryTab;
	private javax.swing.JTextField roomBox;
	private javax.swing.JPanel pidPanel;
	private javax.swing.JTextArea xmlBox;
	private javax.swing.JTextField phoneNumberBox;
	private javax.swing.JLabel patientNameLabel;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JPanel messageGenTab;
	private javax.swing.JScrollPane xmlScroller;
	private javax.swing.JTextField patientNameBox;
	private javax.swing.JPanel panelPV1;
	private javax.swing.JTextField bedBox;
	private javax.swing.JLabel postalCodeLabel;
	private javax.swing.JTextField dateTimeOfMessage;
	private javax.swing.JSpinner telephoneSpinner;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel namePanel;
	private javax.swing.JButton generateButton;
	private javax.swing.JTextField sequenceID;
	private javax.swing.JSpinner locationSpinner;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JTextField postalCodeBox;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JLabel bedLabel;
	private javax.swing.JTabbedPane tabPane;
	private javax.swing.JLabel phoneNumberLabel;
	private javax.swing.JLabel roomLabel;
	private javax.swing.JLabel buildingLabel;
	private javax.swing.JTextField building;
	// End of variables declaration

}
